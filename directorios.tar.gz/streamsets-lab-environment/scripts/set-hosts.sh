#!/bin/bash

#backup /etc/hosts
sudo cp -p /etc/hosts /etc/hosts.bak

#clean up /etc/hosts
hosts=(mysqldb influxdb mailhog openldap sch sch_sdc sdc-node1 sdc-node2 transformer-node1 transformer-node2 zookeeper kafka oracle namenode datanode resourcemanager nodemanager historyserver hive-server hive-metastore spark-master spark-worker-1 cdh jupyter-tf jenkins)

for host in "${hosts[@]}"
do
  sudo sed -i "/$host/d" /etc/hosts
done

#update /etc/hosts
echo "172.90.0.10 mysqldb" | sudo tee -a /etc/hosts
echo "172.90.0.11 influxdb" | sudo tee -a /etc/hosts
echo "172.90.0.12 mailhog" | sudo tee -a /etc/hosts
echo "172.90.0.13 openldap" | sudo tee -a /etc/hosts

#streamsets-cooked
echo "172.100.0.10 sch" | sudo tee -a /etc/hosts
echo "172.100.0.11 sch_sdc" | sudo tee -a /etc/hosts
echo "172.100.0.21 sdc-node1" | sudo tee -a /etc/hosts
echo "172.100.0.22 sdc-node2" | sudo tee -a /etc/hosts
echo "172.100.0.31 transformer-node1" | sudo tee -a /etc/hosts
echo "172.100.0.32 transformer-node2" | sudo tee -a /etc/hosts

#streamsets-uncooked
echo "172.100.0.110 sch_new" | sudo tee -a /etc/hosts
echo "172.100.0.111 sch_sdc_new" | sudo tee -a /etc/hosts
echo "172.100.0.121 sdc-node1-new" | sudo tee -a /etc/hosts
echo "172.100.0.122 sdc-node2-new" | sudo tee -a /etc/hosts
echo "172.100.0.131 transformer-node1-new" | sudo tee -a /etc/hosts
echo "172.100.0.132 transformer-node2-new" | sudo tee -a /etc/hosts

#kafka
echo "172.110.0.10 zookeeper" | sudo tee -a /etc/hosts
echo "172.110.0.20 kafka" | sudo tee -a /etc/hosts

#oracle
echo "172.110.0.30 oracle" | sudo tee -a /etc/hosts

#cdh
echo "172.110.0.40 cdh" | sudo tee -a /etc/hosts

#hadoop and hive (big data europe aka bde)
echo "172.110.0.50 namenode" | sudo tee -a /etc/hosts
echo "172.110.0.51 datanode" | sudo tee -a /etc/hosts

echo "172.110.0.60 resourcemanager" | sudo tee -a /etc/hosts
echo "172.110.0.61 nodemanager" | sudo tee -a /etc/hosts
echo "172.110.0.62 historyserver" | sudo tee -a /etc/hosts

echo "172.110.0.70 hive-server" | sudo tee -a /etc/hosts
echo "172.110.0.71 hive-metastore" | sudo tee -a /etc/hosts

#spark (big data europe aka bde)
echo "172.110.0.80 spark-master" | sudo tee -a /etc/hosts
echo "172.110.0.81 spark-worker-1" | sudo tee -a /etc/hosts 

#jupyter-tensorflow
echo "172.110.0.90 jupyter-tf" | sudo tee -a /etc/hosts 

#jenkins
echo "172.110.0.100 jenkins" | sudo tee -a /etc/hosts 

