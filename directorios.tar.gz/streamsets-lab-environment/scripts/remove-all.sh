#!/bin/bash

sudo docker-compose -f ../streamsets-cooked/docker-compose.yml --compatibility down
sudo docker-compose -f ../streamsets-core/docker-compose.yml --compatibility down
sudo docker-compose -f ../kafka/docker-compose.yml --compatibility down
