#!/bin/bash

#Remove existing deployment
sudo /bin/bash remove-all.sh

#Create the Networks
sudo docker network create --gateway 172.90.0.1 --subnet 172.90.0.0/24 streamsets-core
sudo docker network create --gateway 172.100.0.1 --subnet 172.100.0.0/24 streamsets-cooked
sudo docker network create --gateway 172.110.0.1 --subnet 172.110.0.0/24 streamsets-integrations

sudo /bin/bash set-hosts.sh

#Launch Dockers
sudo docker-compose -f ../streamsets-core/docker-compose.yml --compatibility up -d
sleep 10
sudo docker-compose -f ../streamsets-cooked/docker-compose.yml --compatibility up -d
sudo docker-compose -f ../kafka/docker-compose.yml --compatibility up -d
sudo docker-compose -f ../oracle/docker-compose.yml --compatibility up -d
sudo docker-compose -f ../hadoop/docker-compose.yml --compatibility up -d
sudo docker-compose -f ../spark/docker-compose.yml --compatibility up -d


