#!/bin/bash

docker-compose --compatibility up -d

docker exec -u root transformer-node1 bash -c "echo http://dl-cdn.alpinelinux.org/alpine/v3.10/main >> /etc/apk/repositories"
docker exec -u root transformer-node1 bash -c "apk update"
docker exec -u root transformer-node1 bash -c "apk add gcc g++ gfortran freetype-dev libpng-dev openblas-dev python3-dev=3.7.10-r0"
docker exec -u root transformer-node1 bash -c "pip3 install numpy"